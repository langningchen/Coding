#include <bits/stdc++.h>
using namespace std;
int a, b;
int main()
{
    cin >> a >> b;
    cout << fixed << setprecision(2) << 1.0 / (1.0 / a + 1.0 / b) << endl;
    return 0;
}