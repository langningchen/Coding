#include <bits/stdc++.h>
using namespace std;
char c;
int main()
{
    cin >> c;
    cout << "  " << c << endl;
    cout << " " << c << c << c << endl;
    cout << c << c << c << c << c << endl;
    return 0;
}