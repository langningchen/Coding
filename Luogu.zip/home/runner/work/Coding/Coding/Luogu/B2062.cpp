#include <bits/stdc++.h>
using namespace std;
int a, n;
int main()
{
    cin >> a >> n;
    cout << pow(a, n) << endl;
    return 0;
}