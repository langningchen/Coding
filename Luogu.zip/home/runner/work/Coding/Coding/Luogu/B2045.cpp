#include <bits/stdc++.h>
using namespace std;
int n;
int main()
{
    cin >> n;
    if (n == 1 || n == 3 || n == 5)
        cout << "NO" << endl;
    else
        cout << "YES" << endl;
    return 0;
}