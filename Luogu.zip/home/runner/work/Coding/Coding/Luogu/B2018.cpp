#include <bits/stdc++.h>
using namespace std;
int c;
int main()
{
    cin >> c;
    cout << (char)c << endl;
    return 0;
}