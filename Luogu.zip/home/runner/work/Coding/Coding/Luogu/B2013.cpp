#include <bits/stdc++.h>
using namespace std;
double F;
int main()
{
    cin >> F;
    cout << fixed << setprecision(5) << 5.0 * (F - 32) / 9 << endl;
    return 0;
}