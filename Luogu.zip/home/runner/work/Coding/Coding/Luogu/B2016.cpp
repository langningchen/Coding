#include <bits/stdc++.h>
using namespace std;
double x;
int main()
{
    cin >> x;
    cout << (long long)x << endl;
    return 0;
}