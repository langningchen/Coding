#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a, b, c;
int main()
{
    cin >> a >> b >> c;
    cout << (a + b) / c << endl;
    return 0;
}