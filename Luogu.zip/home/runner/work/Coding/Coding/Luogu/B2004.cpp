#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a, b, c;
int main()
{
    cin >> a >> b >> c;
    cout << setw(8) << a << " " << setw(8) << b << " " << setw(8) << c << endl;
    return 0;
}