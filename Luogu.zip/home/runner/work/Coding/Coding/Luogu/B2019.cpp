#include <bits/stdc++.h>
using namespace std;
int x;
int main()
{
    cin >> x;
    cout << (x == 0 ? 0 : 1) << endl;
    return 0;
}