#include <bits/stdc++.h>
using namespace std;
const double PI = 3.14159;
double r;
int main()
{
    cin >> r;
    cout << fixed << setprecision(4) << r * 2 << " " << r * 2 * PI << " " << r * r * PI << endl;
    return 0;
}