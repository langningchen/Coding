#include <bits/stdc++.h>
using namespace std;
int a, b;
int main()
{
    cin >> a >> b;
    cout << (a >= 10 || b >= 20) << endl;
    return 0;
}