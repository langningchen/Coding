#include <bits/stdc++.h>
using namespace std;
double d;
int main()
{
    cin >> d;
    printf("%f\n%0.5f\n%e\n%g\n", d, d, d, d);
    return 0;
}