#include <bits/stdc++.h>
using namespace std;
int n;
int main()
{
    cin >> n;
    cout << n * (n + 1) / 2 << endl;
    return 0;
}