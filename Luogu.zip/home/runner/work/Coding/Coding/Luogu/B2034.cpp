#include <bits/stdc++.h>
using namespace std;
int n;
int main()
{
    cin >> n;
    cout << (int)pow(2, n) << endl;
    return 0;
}