#include <bits/stdc++.h>
using namespace std;
char c;
int main()
{
    cin >> c;
    cout << (int)c << endl;
    return 0;
}