#include <bits/stdc++.h>
using namespace std;
double n;
int main()
{
    cin >> n;
    cout << fixed << setprecision(2) << abs(n) << endl;
    return 0;
}