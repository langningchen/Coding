#include <bits/stdc++.h>
using namespace std;
const double PI = 3.14;
int r;
int main()
{
    cin >> r;
    cout << fixed << setprecision(5) << 4.0 / 3 * PI * r * r * r << endl;
    return 0;
}