#include <bits/stdc++.h>
using namespace std;
int main() {
    long long a, b, c;
    cin >> a >> b >> c;
	cout << (a * a > b * c ? "Alice" : "Bob") << endl;
	return 0;
}

