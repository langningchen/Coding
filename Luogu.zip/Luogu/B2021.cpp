#include <bits/stdc++.h>
using namespace std;
float x;
int main()
{
    cin >> x;
    cout << fixed << setprecision(3) << x << endl;
    return 0;
}