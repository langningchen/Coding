#include <bits/stdc++.h>
using namespace std;
string n;
int main()
{
    cin >> n;
    if (n.size() == 2)
        cout << 1 << endl;
    else
        cout << 0 << endl;
    return 0;
}