#include <bits/stdc++.h>
using namespace std;
int a, b;
int main()
{
    cin >> a >> b;
    cout << fixed << setprecision(3) << b * 100.0 / a << "%" << endl;
    return 0;
}