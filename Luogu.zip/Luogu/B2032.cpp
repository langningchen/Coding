#include <bits/stdc++.h>
using namespace std;
int a, b, n;
int main()
{
    cin >> a >> b >> n;
    cout << (n - 2) * (b - a) + b << endl;
    return 0;
}