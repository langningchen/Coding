#include <bits/stdc++.h>
using namespace std;
string s;
int i;
float f;
double d;
int main()
{
    cin >> s >> i >> f >> d;
    cout << s << " " << i << " " << fixed << setprecision(6) << f << " " << d << endl;
    return 0;
}