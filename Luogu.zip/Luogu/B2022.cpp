#include <bits/stdc++.h>
using namespace std;
double x;
int main()
{
    cin >> x;
    cout << fixed << setprecision(12) << x << endl;
    return 0;
}