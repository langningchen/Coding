#include <bits/stdc++.h>
using namespace std;
char n;
int main()
{
    cin >> n;
    cout << ((int)n % 2 == 0 ? "NO" : "YES") << endl;
    return 0;
}