// Copyright (c) 2019 Nomango

#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>
