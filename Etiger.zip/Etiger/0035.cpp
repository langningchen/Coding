#include <bits/stdc++.h>
using namespace std;
double n;
int main()
{
    cin >> n;
    cout << (9.0 / 5) * n + 32;
    if ((int)((9.0 / 5) * n + 32) == ((9.0 / 5) * n + 32))
        cout << ".0" << endl;
    return 0;
}