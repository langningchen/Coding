// Copyright (c) 2021 Nomango

#pragma once

#include <catch2/catch.hpp>
#include <configor/configor.hpp>

using namespace configor;
