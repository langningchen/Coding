#include <bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin >> n;
	for (int i = 3; i <= n; i += 3)
		cout << i << " ";
	cout << endl;
	return 0;
}
