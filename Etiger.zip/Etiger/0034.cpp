#include <bits/stdc++.h>
using namespace std;
string s1, s2;
int main()
{
    cout << "What's your name?" << endl;
    cin >> s1;
    cout << s1 << ", your favorite color?" << endl;
    cin >> s2;
    cout << s1 << " likes " << s2 << ".";
    return 0;
}