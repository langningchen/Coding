#include <bits/stdc++.h>
using namespace std;
int main()
{
	int a;
	cin >> a;
	cout << (a % 3 == 0 ? "Yes" : "No") << endl;
	return 0;
}
