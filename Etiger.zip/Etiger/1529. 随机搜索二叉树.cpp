#include <bits/stdc++.h>
using namespace std;
int main() {
    freopen("search.in", "r", stdin);
    freopen("search.out", "w", stdout);
    int n;
    cin >> n;
    cout << n - 1 << ".000" << endl;
    return 0;
}

