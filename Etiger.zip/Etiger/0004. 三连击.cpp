#include <iostream>

using namespace std;

int main() {
  cout << "192 384 576" << endl;
  cout << "219 438 657" << endl;
  cout << "273 546 819" << endl;
  cout << "327 654 981" << endl;
  //shou suan de
  return 0;
}
