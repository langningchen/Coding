#include <bits/stdc++.h>
using namespace std;
int main()
{
	int a;
	cin >> a;
	cout << (a >= 60 ? "Pass" : "Fail") << endl;
	return 0;
}
