#include <bits/stdc++.h>
using namespace std;
int main() {
    map<string, int> pw;
    string s;
    while(cin >> s)
        pw[s]++;
    return 0;
}
