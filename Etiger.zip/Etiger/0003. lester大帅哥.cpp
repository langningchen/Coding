#include <iostream>
using namespace std;
int main() {
  cout << "lester��˧��" << endl;
  return 0;
}
