#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n;
int main()
{
    freopen("maiev.in", "r", stdin);
    freopen("maiev.out", "w", stdout);
    cin >> n;
    cout << (n + 1) * (n + 1) / 2 - 1 << endl;
    return 0;
}