#include <bits/stdc++.h>
using namespace std;
string ans = "CCCABCABACACDDCBDCCCACBCB";
int i;
int main()
{
    cin >> i;
    cout << ans[i - 1] << endl;
    return 0;
}
