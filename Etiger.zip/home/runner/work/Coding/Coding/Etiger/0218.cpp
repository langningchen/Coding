#include <bits/stdc++.h>
using namespace std;
string s;
int main()
{
	cin >> s;
	cout << s.size() << endl;
	return 0;
}
