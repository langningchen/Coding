#include <bits/stdc++.h>
using namespace std;
int s;
int main()
{
	cin >> s;
	int a = ceil(sqrt(s));
	cout << a * a << endl;
	return 0;
}
