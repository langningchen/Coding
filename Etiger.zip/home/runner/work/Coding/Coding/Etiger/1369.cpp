#include <bits/stdc++.h>
using namespace std;
int a, b, c, d;
int main()
{
	cin >> a >> b >> c >> d;
	cout << (abs(c - a) + abs(d - b)) << endl;
	return 0;
}
