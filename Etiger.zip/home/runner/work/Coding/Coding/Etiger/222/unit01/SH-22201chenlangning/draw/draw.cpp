#include <bits/stdc++.h>
using namespace std;
int main()
{
#ifndef LOCAL
	freopen("draw.in", "r", stdin);
	freopen("draw.out", "w", stdout);
#endif
	return 0;
}
