#include <bits/stdc++.h>
using namespace std;
int main()
{
    double a, b, c;
    cin >> a >> b >> c;
    cout << fixed << setprecision(2) << a * b * c << endl;
    return 0;
}
