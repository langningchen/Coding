#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N = 200005;
const ll M = 10000005;
ll n, s[N], p[N], cnt[M];
int main()
{
    // freopen("share.in", "r", stdin);
    // freopen("share.out", "w", stdout);
    cin >> n;
    for (ll i = 1; i <= n; i++)
        cin >> p[i];
    for (ll i = 1; i <= n; i++)
    {
        s[i];
    }
    return 0;
}