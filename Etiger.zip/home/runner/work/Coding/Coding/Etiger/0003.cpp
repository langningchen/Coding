#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout << "lester大帅哥" << endl;
    return 0;
}
