#include <bits/stdc++.h>
using namespace std;
int main()
{
	cout << "6.00" << endl;
	cout << "10.40" << endl;
	cout << "30.24" << endl;
	return 0;
}
