#include <bits/stdc++.h>
using namespace std;
int main()
{
	cout << 60.2 << endl;
	return 0;
}
