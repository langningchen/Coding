#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a, b;
int main()
{
	freopen("ab.in", "r", stdin);
	freopen("ab.out", "w", stdout);
	cin >> a >> b;
	cout << a * b << endl;
	return 0;
}
