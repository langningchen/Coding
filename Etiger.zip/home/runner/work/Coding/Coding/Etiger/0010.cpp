#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout << "C++ runs fast";
    return 0;
}