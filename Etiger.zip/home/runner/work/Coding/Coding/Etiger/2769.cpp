#include <bits/stdc++.h>
using namespace std;
int main()
{
    // freopen("apology.in", "r", stdin);
    // freopen("apology.out", "w", stdout);
    return 0;
}
