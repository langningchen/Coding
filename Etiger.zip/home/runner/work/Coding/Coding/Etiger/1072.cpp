#include <bits/stdc++.h>
using namespace std;
int main()
{
	int a;
	cin >> a;
	cout << (a >= 100 ? 7 * a : 10 * a) << endl;
	return 0;
}
