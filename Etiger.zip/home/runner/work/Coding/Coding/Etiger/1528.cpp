#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("casinoroyale3.in", "r", stdin);
    freopen("casinoroyale3.out", "w", stdout);
    int a, b;
    cin >> a >> b;
    cout << fixed << setprecision(3) << a * 1.0 * b << endl;
    return 0;
}
