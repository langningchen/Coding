#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("blindbox1.in", "r", stdin);
    freopen("blindbox1.out", "w", stdout);
    int n;
    cin >> n;
    cout << n << ".000" << endl;
    return 0;
}
