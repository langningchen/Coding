#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout << "The world is a distributed network." << endl;
    cout << "You are not a commodity." << endl;
    cout << "You are not a lottery ticket." << endl;
    cout << "Life is short. Use Python." << endl;
    return 0;
}