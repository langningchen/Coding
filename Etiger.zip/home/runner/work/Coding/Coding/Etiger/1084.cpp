#include <bits/stdc++.h>
using namespace std;
int main()
{
	int a;
	cin >> a;
	for (int i = 2; i <= a; i += 2)
	{
		cout << i << " ";
	}
	cout << endl;
	return 0;
}
