#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout << "Talk is cheap. Show me the code." << endl;
    cout << "Good design adds value faster than it adds cost." << endl;
    cout << "In theory, theory and practice are the same. In practice, they're not." << endl;
    cout << "Debugging is twice as hard as writing the code in the first place." << endl;
    return 0;
}