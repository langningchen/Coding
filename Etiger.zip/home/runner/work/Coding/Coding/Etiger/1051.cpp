#include <bits/stdc++.h>
using namespace std;
int main()
{
	int a, b;
	cin >> a >> b;
	cout << fixed << setprecision(1) << ((a + b) / 2.0) << endl;
	return 0;
}
