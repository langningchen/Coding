#include <bits/stdc++.h>
using namespace std;
int main()
{
	long long a, b, c;
	cin >> a >> b >> c;
	cout << a * 0.2 + b * 0.3 + c * 0.5 << endl;
	return 0;
}
