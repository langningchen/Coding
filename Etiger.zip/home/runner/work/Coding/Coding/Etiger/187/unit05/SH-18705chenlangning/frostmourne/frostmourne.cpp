#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int T, n, m;
int main()
{
    freopen("frontmourne.in", "r", stdin);
    freopen("frontmourne.out", "w", stdout);
    cin >> T >> n;
    for (int i = 0; i < n; i++)
    {
        int x, y;
        cin >> x >> y;
    }
    cin >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        cin >> x >> y;
        cout << "NE" << endl;
    }
    return 0;
}