#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("magtheridon.in", "r", stdin);
    freopen("magtheridon.out", "w", stdout);
    return 0;
}