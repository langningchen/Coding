#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("intersterllar.in", "r", stdin);
    freopen("intersterllar.out", "w", stdout);
    return 0;
}
