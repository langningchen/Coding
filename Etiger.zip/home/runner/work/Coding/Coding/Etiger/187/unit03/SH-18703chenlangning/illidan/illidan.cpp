#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("illidan.in", "r", stdin);
    freopen("illidan.out", "w", stdout);
    return 0;
}