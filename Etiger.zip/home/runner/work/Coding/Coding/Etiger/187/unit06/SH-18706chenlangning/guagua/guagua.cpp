#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("guagua.in", "r", stdin);
    freopen("guagua.out", "w", stdout);
    return 0;
}