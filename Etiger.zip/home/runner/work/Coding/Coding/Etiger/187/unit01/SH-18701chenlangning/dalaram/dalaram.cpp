#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("dalaram.in", "r", stdin);
    freopen("dalaram.out", "w", stdout);
    return 0;
}