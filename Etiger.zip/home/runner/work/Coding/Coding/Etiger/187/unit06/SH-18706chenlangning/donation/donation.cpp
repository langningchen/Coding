#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("donation.in", "r", stdin);
    freopen("donation.out", "w", stdout);
    return 0;
}