#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("kaelthas.in", "r", stdin);
    freopen("kaelthas.out", "w", stdout);
    return 0;
}