#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("equipment.in", "r", stdin);
    freopen("equipment.out", "w", stdout);
    return 0;
}
